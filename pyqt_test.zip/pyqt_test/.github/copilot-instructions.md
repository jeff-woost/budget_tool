<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# PyQt Zero-Based Budget Tracker Project Instructions

This is a PyQt6-based zero-based budget tracking application with a comprehensive subcategory system and modular structure. When working on this project:

1. **PyQt6 Framework**: Use PyQt6 for all GUI components. Prefer modern PyQt6 syntax and widgets.

2. **Zero-Based Budgeting Philosophy**: 
   - Every dollar of income should be allocated to either expenses or savings
   - Income = Expenses + Savings (zero remaining)
   - Support multiple income sources and detailed expense categorization
   - Track progress toward savings goals

3. **Hierarchical Category System**:
   - Main categories (Housing, Food, Healthcare, etc.)
   - Detailed subcategories within each main category
   - Format: "MainCategory:Subcategory" (e.g., "Food:Groceries")
   - Based on real-world spending patterns from the sub_categories.pl file

4. **Project Structure**: 
   - `src/` contains all source code organized by functionality
   - `src/gui/` contains UI components including main window and tab widgets
   - `src/data/` contains data management and persistence logic
   - `src/utils/` contains helper functions, utilities, and category management
   - `app.py` is the main entry point

5. **Data Architecture**: 
   - Separate storage for expenses, income entries, budgets, and savings goals
   - All data managed through the `DataManager` class in `src/data/data_manager.py`
   - Category management through `CategoryManager` class in `src/utils/categories.py`
   - Support for transaction types: income, expense, savings

6. **Code Structure**: 
   - Main application logic is in `src/gui/main_window.py`
   - Individual tabs are in `src/gui/tabs/` directory
   - `SpendingTab`: Transaction entry with income/expense/savings support
   - `ZeroBasedBudgetTab`: Multi-tab budget management (income, allocation, savings, overview)
   - `ReportsTab`: Analytics and reporting with subcategory breakdowns
   - Follow the existing pattern of separating UI creation, data management, and event handling
   - Use descriptive method names and maintain consistent styling
   - Import using relative imports within the package structure

7. **UI Guidelines**:
   - Use tabs for different functionality (Transactions, Zero-Based Budget, Reports)
   - Implement hierarchical category selection (main → subcategory)
   - Provide clear transaction type selection (Income/Expense/Savings)
   - Apply consistent styling using Qt stylesheets
   - Ensure responsive layouts that work with window resizing
   - Use signals and slots for communication between components
   - Color-code budget progress and balance indicators

8. **Zero-Based Budget Features**:
   - Income planning with multiple sources
   - Category:subcategory budget allocation
   - Savings goal setting and tracking
   - Budget balance overview (income vs allocated funds)
   - Visual progress indicators for all budget categories

9. **Transaction Management**:
   - Support income, expense, and savings transaction types
   - Detailed categorization with main category + subcategory selection
   - Transaction history with type indicators
   - Edit and delete capabilities

10. **Best Practices**:
    - Always save data after modifications through DataManager
    - Provide user feedback for actions (success/error messages)
    - Use proper error handling for file operations
    - Implement confirmation dialogs for destructive actions
    - Follow the modular structure when adding new features
    - Use type hints for better code documentation
    - Maintain separation between income, expenses, and savings in data structures
   - Use proper error handling for file operations
   - Implement confirmation dialogs for destructive actions
   - Follow the modular structure when adding new features
   - Use type hints for better code documentation
