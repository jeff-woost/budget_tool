#!/usr/bin/env python3
"""
Budget Tracker Launcher
Simple launcher script for the PyQt Budget Tracker application.
"""

import subprocess
import sys
import os

def main():
    """Launch the Budget Tracker application."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    main_script = os.path.join(script_dir, "app.py")
    
    try:
        subprocess.run([sys.executable, main_script], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error running Budget Tracker: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nBudget Tracker closed by user.")
        sys.exit(0)

if __name__ == "__main__":
    main()
