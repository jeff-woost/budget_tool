# PyQt Zero-Based Budget Tracker

A comprehensive, user-friendly desktop application for zero-based budgeting with detailed subcategory tracking, built with PyQt6.

## Features

### 🏦 Zero-Based Budgeting
- **Income Planning**: Track multiple income sources and expected amounts
- **Complete Allocation**: Ensure every dollar has a purpose (expenses or savings)
- **Savings Goals**: Set and track specific savings targets
- **Budget Balance**: Visual feedback when income doesn't equal allocated funds

### 📊 Advanced Transaction Management
- **Income & Expense Tracking**: Record all financial transactions in one place
- **Detailed Categories**: 15+ main categories with 100+ subcategories
- **Hierarchical Organization**: Main categories (Housing, Food, etc.) with specific subcategories
- **Transaction Types**: Distinguish between income, expenses, and savings allocations
- **📁 CSV Bulk Import**: Upload bank statements and credit card exports for easy data entry
- **🤖 Smart Auto-Categorization**: Automatically categorize imported transactions based on description keywords

### 📈 Comprehensive Reporting
- **Monthly Summaries**: Track income vs expenses vs savings
- **Category Analysis**: Detailed breakdown by main category and subcategory
- **Budget vs Actual**: Compare planned spending with actual expenses
- **Progress Tracking**: Visual progress bars for budget categories and savings goals

### 🎯 Smart Category System
Based on real-world spending patterns with categories including:
- **Housing**: Mortgage, HOA, Property Taxes, Utilities, Maintenance
- **Food**: Groceries, Dining Out, Work Meals, Special Occasions
- **Transportation**: Gas, Insurance, Maintenance, Public Transit
- **Healthcare**: Doctor Visits, Prescriptions, Insurance, Personal Care
- **Childcare**: Clothing, Activities, Education, Baby Supplies
- **And many more...**

## Screenshots

The application features a comprehensive tabbed interface:

### 🏦 Transactions Tab
- **Transaction Types**: Toggle between Income, Expense, and Savings entries
- **Hierarchical Categories**: Select main category (e.g., "Food") then subcategory (e.g., "Groceries")
- **Transaction History**: View all transactions with type indicators and delete options
- **Smart Categorization**: Auto-populating subcategories based on main category selection
- **📁 CSV Upload**: Bulk import transactions from bank/credit card statements
  - **Required Columns**: Transaction Date, Description, Amount
  - **Smart Parsing**: Handles multiple date formats and currency symbols
  - **Interactive Categorization**: Review and categorize imported transactions before saving
  - **Auto-Categorization**: Keyword-based automatic category assignment

### 💰 Zero-Based Budget Tab
- **Income Planning**: Set up expected monthly income from multiple sources
- **Budget Allocation**: Assign specific amounts to category:subcategory combinations
- **Savings Goals**: Define and track progress toward savings targets
- **Balance Overview**: Ensure total income equals total allocated funds (zero-based principle)

### 📊 Reports Tab
- **Monthly Analysis**: Income vs expenses vs savings breakdown
- **Category Spending**: Detailed spending by main categories and subcategories
- **Budget Performance**: Compare budgeted amounts with actual spending
- **Trend Analysis**: Track spending patterns over time

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Setup Instructions

## 🎨 Modern User Interface

The application features a vibrant, user-friendly design with:
- **Gradient Backgrounds**: Beautiful color transitions throughout the interface
- **Color-Coded Buttons**: 
  - 🟢 Green gradients for primary actions (Add Transaction)
  - 🟠 Orange gradients for CSV upload functionality
  - 🔴 Red gradients for delete operations
- **Interactive Elements**: Hover effects and visual feedback on all buttons and inputs
- **Modern Typography**: Clean, readable fonts with proper sizing and weight
- **Professional Color Scheme**: Based on modern design principles with blue, green, and accent colors
- **Enhanced Tables**: Better spacing, colors, and visual hierarchy
- **Improved Tab Design**: Clear active/inactive states with gradient backgrounds

## Installation

1. **Clone or download the project**:
   ```bash
   git clone <repository-url>
   cd pyqt_test
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**:
   ```bash
   python app.py
   ```

## Usage

### Zero-Based Budgeting Workflow

1. **Set Up Income Sources** (Zero-Based Budget → Income Planning):
   - Add all expected monthly income sources
   - Include salary, freelance, investments, etc.
   - Set realistic expected amounts

2. **Allocate Every Dollar** (Zero-Based Budget → Budget Allocation):
   - Create budgets for each spending category:subcategory
   - Example: "Food:Groceries" = $400, "Food:Dining Out" = $150
   - Ensure total budgets + savings goals = total income

3. **Set Savings Goals** (Zero-Based Budget → Savings Goals):
   - Define specific savings targets (Emergency Fund, Vacation, etc.)
   - Set monthly contribution amounts
   - Track progress toward goals

4. **Record Transactions** (Transactions Tab):
   - Log all income as it comes in
   - Record every expense with detailed categorization
   - Use the hierarchical category system for precise tracking
   - **📁 Bulk Import from CSV**: Upload bank/credit card statements for efficient data entry

5. **Monitor Progress** (Reports Tab):
   - Review monthly spending vs budget
   - Analyze spending patterns by category
   - Adjust budgets based on actual spending

### 📁 CSV Import Feature

The application supports bulk import of transactions from CSV files (bank statements, credit card exports, etc.):

#### CSV Format Requirements
Your CSV file must contain these columns:
- **Transaction Date**: Date of the transaction (supports formats: MM/DD/YY, MM/DD/YYYY, YYYY-MM-DD, DD/MM/YYYY)
- **Description**: Transaction description/merchant name
- **Amount**: Transaction amount (negative values are converted to positive expenses)

#### Import Process
1. **Click "📁 Upload CSV"** button in the Transactions tab
2. **Select your CSV file** using the file dialog
3. **Review imported transactions** in the categorization dialog
4. **Use Auto-Categorize** to automatically assign categories based on description keywords
5. **Manually categorize** any remaining transactions using the dropdown menus
6. **Confirm import** to add all categorized transactions to your budget

#### Auto-Categorization Keywords
The system automatically recognizes common transaction patterns:
- **grocery**, **walmart**, **acme** → Shopping:Groceries
- **gas**, **exxon**, **shell** → Transportation:Gas
- **restaurant**, **dining** → Food:Dining Out
- **coffee**, **starbucks** → Food:Coffee/Tea
- **uber**, **lyft** → Transportation:Rideshare
- **amazon** → Shopping:Online Shopping
- **netflix**, **spotify** → Entertainment:Streaming Services
- **gym**, **fitness** → Health:Fitness
- **pharmacy**, **walgreens** → Health:Pharmacy
- **doctor**, **medical** → Health:Medical

### Adding Transactions
1. Navigate to the "Transactions" tab
2. Select transaction type: Income, Expense, or Savings
3. Choose main category (e.g., "Food", "Housing", "Income")
4. Select or enter specific subcategory
5. Enter amount, date, and description
6. Click "Add Transaction"

### Setting Up Budgets
1. Go to "Zero-Based Budget" → "Budget Allocation"
2. Select main category and subcategory
3. Enter monthly budget amount
4. Monitor spending with visual progress indicators
5. Adjust allocations as needed to achieve zero-based balance

## Data Storage

The application stores all data in a local `budget_data.json` file with the following structure:

```json
{
  "expenses": [
    {
      "date": "2025-01-15",
      "amount": 45.67,
      "category": "Food:Groceries",
      "description": "Weekly grocery shopping",
      "type": "expense"
    }
  ],
  "income_entries": [
    {
      "date": "2025-01-01",
      "amount": 5000.00,
      "category": "Income:Salary",
      "description": "Monthly salary",
      "type": "income"
    }
  ],
  "budgets": {
    "Food:Groceries": 400.00,
    "Food:Dining Out": 150.00,
    "Housing:Rent": 1200.00
  },
  "savings_goals": {
    "Emergency Fund": 500.00,
    "Vacation Fund": 200.00
  }
}
```

## Project Structure

```
pyqt_test/
├── app.py                     # Main application entry point
├── main.py                    # Legacy main file (preserved)
├── run_budget_tracker.py      # Launcher script
├── requirements.txt           # Python dependencies
├── budget_data.json          # Data file (created automatically)
├── README.md                 # This file
├── src/                      # Source code directory
│   ├── __init__.py           # Package initialization
│   ├── gui/                  # GUI components
│   │   ├── __init__.py
│   │   ├── main_window.py    # Main application window
│   │   └── tabs/             # Individual tab widgets
│   │       ├── __init__.py
│   │       ├── spending_tab.py
│   │       ├── budget_tab.py
│   │       └── reports_tab.py
│   ├── data/                 # Data management
│   │   ├── __init__.py
│   │   └── data_manager.py   # Data persistence logic
│   └── utils/                # Utility functions
│       ├── __init__.py
│       └── helpers.py        # Helper functions
└── .github/
    └── copilot-instructions.md # Development guidelines
```

## Development

### Code Structure
- **BudgetTracker**: Main application class in `src/gui/main_window.py`
- **Tab Management**: Individual tab widgets in `src/gui/tabs/`
- **Data Management**: JSON-based persistence in `src/data/data_manager.py`
- **Utilities**: Helper functions in `src/utils/helpers.py`
- **Modular Design**: Separated concerns with clear package structure

### Adding New Features
When extending the application:
1. Follow the existing pattern of separating UI creation and business logic
2. Update the data model in the JSON structure if needed
3. Ensure UI updates reflect data changes
4. Add appropriate input validation and user feedback

## Troubleshooting

### Common Issues
- **ImportError**: Ensure PyQt6 is properly installed with `pip install PyQt6`
- **Data Loss**: The application auto-saves, but backup your `budget_data.json` file periodically
- **Display Issues**: Try adjusting the window size or restarting the application

## License

This project is open source and available under the MIT License.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.
