import sys
import json
import os
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton,
    QLabel, QLineEdit, QComboBox, QTableWidget, QTableWidgetItem,
    QMessageBox, QDateEdit, QDoubleSpinBox, QTabWidget,
    QProgressBar, QGroupBox, QGridLayout, QHeaderView
)
from PyQt6.QtCore import QDate


class BudgetTracker(QMainWindow):
    def __init__(self):
        super().__init__()
        self.data_file = "budget_data.json"
        self.load_data()
        self.init_ui()
        
    def init_ui(self):
        self.setWindowTitle("Budget Spending Tracker")
        self.setGeometry(100, 100, 1000, 700)
        
        # Set up main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        # Create tab widget
        tab_widget = QTabWidget()
        main_layout = QVBoxLayout(main_widget)
        main_layout.addWidget(tab_widget)
        
        # Create tabs
        self.create_spending_tab(tab_widget)
        self.create_budget_tab(tab_widget)
        self.create_reports_tab(tab_widget)
        
        # Apply styling
        self.apply_styling()
        
    def create_spending_tab(self, tab_widget):
        spending_tab = QWidget()
        layout = QVBoxLayout(spending_tab)
        
        # Add expense section
        expense_group = QGroupBox("Add New Expense")
        expense_layout = QGridLayout(expense_group)
        
        # Date input
        expense_layout.addWidget(QLabel("Date:"), 0, 0)
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        expense_layout.addWidget(self.date_edit, 0, 1)
        
        # Amount input
        expense_layout.addWidget(QLabel("Amount:"), 0, 2)
        self.amount_input = QDoubleSpinBox()
        self.amount_input.setMaximum(99999.99)
        self.amount_input.setPrefix("$")
        expense_layout.addWidget(self.amount_input, 0, 3)
        
        # Category input
        expense_layout.addWidget(QLabel("Category:"), 1, 0)
        self.category_combo = QComboBox()
        self.category_combo.setEditable(True)
        self.update_category_combo()
        expense_layout.addWidget(self.category_combo, 1, 1)
        
        # Description input
        expense_layout.addWidget(QLabel("Description:"), 1, 2)
        self.description_input = QLineEdit()
        expense_layout.addWidget(self.description_input, 1, 3)
        
        # Add button
        add_button = QPushButton("Add Expense")
        add_button.clicked.connect(self.add_expense)
        expense_layout.addWidget(add_button, 2, 0, 1, 4)
        
        layout.addWidget(expense_group)
        
        # Expenses table
        self.expenses_table = QTableWidget()
        self.expenses_table.setColumnCount(5)
        self.expenses_table.setHorizontalHeaderLabels(["Date", "Amount", "Category", "Description", "Actions"])
        self.expenses_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.expenses_table)
        
        # Update table
        self.update_expenses_table()
        
        tab_widget.addTab(spending_tab, "Spending")
        
    def create_budget_tab(self, tab_widget):
        budget_tab = QWidget()
        layout = QVBoxLayout(budget_tab)
        
        # Budget setup section
        budget_group = QGroupBox("Set Category Budgets")
        budget_layout = QGridLayout(budget_group)
        
        budget_layout.addWidget(QLabel("Category:"), 0, 0)
        self.budget_category_combo = QComboBox()
        self.budget_category_combo.setEditable(True)
        self.update_budget_category_combo()
        budget_layout.addWidget(self.budget_category_combo, 0, 1)
        
        budget_layout.addWidget(QLabel("Monthly Budget:"), 0, 2)
        self.budget_amount_input = QDoubleSpinBox()
        self.budget_amount_input.setMaximum(99999.99)
        self.budget_amount_input.setPrefix("$")
        budget_layout.addWidget(self.budget_amount_input, 0, 3)
        
        set_budget_button = QPushButton("Set Budget")
        set_budget_button.clicked.connect(self.set_budget)
        budget_layout.addWidget(set_budget_button, 1, 0, 1, 4)
        
        layout.addWidget(budget_group)
        
        # Budget overview
        overview_group = QGroupBox("Budget Overview")
        self.budget_overview_layout = QVBoxLayout(overview_group)
        layout.addWidget(overview_group)
        
        self.update_budget_overview()
        
        tab_widget.addTab(budget_tab, "Budget")
        
    def create_reports_tab(self, tab_widget):
        reports_tab = QWidget()
        layout = QVBoxLayout(reports_tab)
        
        # Summary section
        summary_group = QGroupBox("Monthly Summary")
        summary_layout = QVBoxLayout(summary_group)
        
        self.total_spent_label = QLabel("Total Spent This Month: $0.00")
        self.total_budget_label = QLabel("Total Budget: $0.00")
        self.remaining_budget_label = QLabel("Remaining Budget: $0.00")
        
        summary_layout.addWidget(self.total_spent_label)
        summary_layout.addWidget(self.total_budget_label)
        summary_layout.addWidget(self.remaining_budget_label)
        
        layout.addWidget(summary_group)
        
        # Category breakdown
        breakdown_group = QGroupBox("Category Breakdown")
        self.breakdown_layout = QVBoxLayout(breakdown_group)
        layout.addWidget(breakdown_group)
        
        self.update_reports()
        
        tab_widget.addTab(reports_tab, "Reports")
        
    def load_data(self):
        """Load data from JSON file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                    self.expenses = data.get('expenses', [])
                    self.budgets = data.get('budgets', {})
            except json.JSONDecodeError:
                self.expenses = []
                self.budgets = {}
        else:
            self.expenses = []
            self.budgets = {}
            
    def save_data(self):
        """Save data to JSON file"""
        data = {
            'expenses': self.expenses,
            'budgets': self.budgets
        }
        with open(self.data_file, 'w') as f:
            json.dump(data, f, indent=2)
            
    def add_expense(self):
        """Add a new expense"""
        date = self.date_edit.date().toString("yyyy-MM-dd")
        amount = self.amount_input.value()
        category = self.category_combo.currentText().strip()
        description = self.description_input.text().strip()
        
        if amount <= 0:
            QMessageBox.warning(self, "Invalid Amount", "Please enter a valid amount greater than 0.")
            return
            
        if not category:
            QMessageBox.warning(self, "Missing Category", "Please enter a category.")
            return
            
        expense = {
            'date': date,
            'amount': amount,
            'category': category,
            'description': description
        }
        
        self.expenses.append(expense)
        self.save_data()
        
        # Clear inputs
        self.amount_input.setValue(0)
        self.category_combo.setCurrentText("")
        self.description_input.clear()
        
        # Update displays
        self.update_expenses_table()
        self.update_category_combo()
        self.update_budget_category_combo()
        self.update_budget_overview()
        self.update_reports()
        
        QMessageBox.information(self, "Success", "Expense added successfully!")
        
    def update_expenses_table(self):
        """Update the expenses table"""
        self.expenses_table.setRowCount(len(self.expenses))
        
        for row, expense in enumerate(self.expenses):
            self.expenses_table.setItem(row, 0, QTableWidgetItem(expense['date']))
            self.expenses_table.setItem(row, 1, QTableWidgetItem(f"${expense['amount']:.2f}"))
            self.expenses_table.setItem(row, 2, QTableWidgetItem(expense['category']))
            self.expenses_table.setItem(row, 3, QTableWidgetItem(expense['description']))
            
            # Add delete button
            delete_button = QPushButton("Delete")
            delete_button.clicked.connect(lambda checked, r=row: self.delete_expense(r))
            self.expenses_table.setCellWidget(row, 4, delete_button)
            
    def delete_expense(self, row):
        """Delete an expense"""
        if row < len(self.expenses):
            reply = QMessageBox.question(self, "Confirm Delete", 
                                       "Are you sure you want to delete this expense?",
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            
            if reply == QMessageBox.StandardButton.Yes:
                del self.expenses[row]
                self.save_data()
                self.update_expenses_table()
                self.update_budget_overview()
                self.update_reports()
                
    def update_category_combo(self):
        """Update category combo box with existing categories"""
        current_text = self.category_combo.currentText()
        self.category_combo.clear()
        
        categories = set(expense['category'] for expense in self.expenses)
        default_categories = ["Food", "Transportation", "Entertainment", "Utilities", "Healthcare", "Shopping", "Other"]
        
        all_categories = sorted(categories.union(default_categories))
        self.category_combo.addItems(all_categories)
        self.category_combo.setCurrentText(current_text)
        
    def update_budget_category_combo(self):
        """Update budget category combo box"""
        current_text = self.budget_category_combo.currentText()
        self.budget_category_combo.clear()
        
        categories = set(expense['category'] for expense in self.expenses)
        default_categories = ["Food", "Transportation", "Entertainment", "Utilities", "Healthcare", "Shopping", "Other"]
        
        all_categories = sorted(categories.union(default_categories))
        self.budget_category_combo.addItems(all_categories)
        self.budget_category_combo.setCurrentText(current_text)
        
    def set_budget(self):
        """Set budget for a category"""
        category = self.budget_category_combo.currentText().strip()
        amount = self.budget_amount_input.value()
        
        if not category:
            QMessageBox.warning(self, "Missing Category", "Please enter a category.")
            return
            
        if amount <= 0:
            QMessageBox.warning(self, "Invalid Amount", "Please enter a valid budget amount greater than 0.")
            return
            
        self.budgets[category] = amount
        self.save_data()
        
        self.budget_amount_input.setValue(0)
        self.budget_category_combo.setCurrentText("")
        
        self.update_budget_overview()
        self.update_reports()
        
        QMessageBox.information(self, "Success", f"Budget set for {category}: ${amount:.2f}")
        
    def update_budget_overview(self):
        """Update budget overview display"""
        # Clear existing widgets
        for i in reversed(range(self.budget_overview_layout.count())):
            child = self.budget_overview_layout.takeAt(i).widget()
            if child:
                child.setParent(None)
                
        if not self.budgets:
            no_budget_label = QLabel("No budgets set. Add some budgets to track your spending!")
            self.budget_overview_layout.addWidget(no_budget_label)
            return
            
        # Get current month expenses
        current_month = datetime.now().strftime("%Y-%m")
        current_expenses = [exp for exp in self.expenses if exp['date'].startswith(current_month)]
        
        for category, budget_amount in self.budgets.items():
            category_spent = sum(exp['amount'] for exp in current_expenses if exp['category'] == category)
            remaining = budget_amount - category_spent
            percentage = min((category_spent / budget_amount) * 100, 100) if budget_amount > 0 else 0
            
            # Create category widget
            category_widget = QWidget()
            category_layout = QVBoxLayout(category_widget)
            
            # Category name and amounts
            info_label = QLabel(f"{category}: ${category_spent:.2f} / ${budget_amount:.2f}")
            category_layout.addWidget(info_label)
            
            # Progress bar
            progress_bar = QProgressBar()
            progress_bar.setValue(int(percentage))
            
            # Color coding
            if percentage >= 100:
                progress_bar.setStyleSheet("QProgressBar::chunk { background-color: #e74c3c; }")
            elif percentage >= 80:
                progress_bar.setStyleSheet("QProgressBar::chunk { background-color: #f39c12; }")
            else:
                progress_bar.setStyleSheet("QProgressBar::chunk { background-color: #27ae60; }")
                
            category_layout.addWidget(progress_bar)
            
            # Remaining amount
            remaining_label = QLabel(f"Remaining: ${remaining:.2f}")
            if remaining < 0:
                remaining_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
            category_layout.addWidget(remaining_label)
            
            self.budget_overview_layout.addWidget(category_widget)
            
    def update_reports(self):
        """Update reports display"""
        # Clear existing widgets
        for i in reversed(range(self.breakdown_layout.count())):
            child = self.breakdown_layout.takeAt(i).widget()
            if child:
                child.setParent(None)
                
        # Get current month data
        current_month = datetime.now().strftime("%Y-%m")
        current_expenses = [exp for exp in self.expenses if exp['date'].startswith(current_month)]
        
        total_spent = sum(exp['amount'] for exp in current_expenses)
        total_budget = sum(self.budgets.values())
        remaining_budget = total_budget - total_spent
        
        # Update summary labels
        self.total_spent_label.setText(f"Total Spent This Month: ${total_spent:.2f}")
        self.total_budget_label.setText(f"Total Budget: ${total_budget:.2f}")
        self.remaining_budget_label.setText(f"Remaining Budget: ${remaining_budget:.2f}")
        
        # Color code remaining budget
        if remaining_budget < 0:
            self.remaining_budget_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
        else:
            self.remaining_budget_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            
        # Category breakdown
        category_totals = {}
        for expense in current_expenses:
            category = expense['category']
            if category in category_totals:
                category_totals[category] += expense['amount']
            else:
                category_totals[category] = expense['amount']
                
        if category_totals:
            breakdown_table = QTableWidget()
            breakdown_table.setColumnCount(3)
            breakdown_table.setHorizontalHeaderLabels(["Category", "Spent", "% of Total"])
            breakdown_table.setRowCount(len(category_totals))
            
            for row, (category, amount) in enumerate(sorted(category_totals.items(), key=lambda x: x[1], reverse=True)):
                percentage = (amount / total_spent) * 100 if total_spent > 0 else 0
                
                breakdown_table.setItem(row, 0, QTableWidgetItem(category))
                breakdown_table.setItem(row, 1, QTableWidgetItem(f"${amount:.2f}"))
                breakdown_table.setItem(row, 2, QTableWidgetItem(f"{percentage:.1f}%"))
                
            breakdown_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            self.breakdown_layout.addWidget(breakdown_table)
        else:
            no_data_label = QLabel("No expenses recorded for this month.")
            self.breakdown_layout.addWidget(no_data_label)
            
    def apply_styling(self):
        """Apply custom styling to the application"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #cccccc;
                border-radius: 5px;
                margin: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:pressed {
                background-color: #21618c;
            }
            QLineEdit, QDoubleSpinBox, QComboBox, QDateEdit {
                padding: 5px;
                border: 1px solid #bdc3c7;
                border-radius: 3px;
            }
            QTableWidget {
                gridline-color: #bdc3c7;
                background-color: white;
            }
            QHeaderView::section {
                background-color: #34495e;
                color: white;
                padding: 8px;
                border: none;
            }
        """)


def main():
    app = QApplication(sys.argv)
    
    # Set application properties
    app.setApplicationName("Budget Spending Tracker")
    app.setOrganizationName("Budget Tracker")
    
    window = BudgetTracker()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
