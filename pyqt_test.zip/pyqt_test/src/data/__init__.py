"""
Data Management Package
Contains classes for data persistence and management.
"""
