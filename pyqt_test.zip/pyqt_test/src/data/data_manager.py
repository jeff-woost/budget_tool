"""
Data Manager Module
Handles loading, saving, and managing budget and expense data with subcategory support.
"""

import json
import os
from typing import Dict, List, Any, Tuple
from ..utils.categories import CategoryManager


class DataManager:
    """Manages budget and expense data persistence with subcategory support."""
    
    def __init__(self, data_file: str = "budget_data.json"):
        """
        Initialize the data manager.
        
        Args:
            data_file: Path to the JSON data file
        """
        self.data_file = data_file
        self.expenses: List[Dict[str, Any]] = []
        self.budgets: Dict[str, float] = {}
        self.income_entries: List[Dict[str, Any]] = []
        self.savings_goals: Dict[str, float] = {}
        self.category_manager = CategoryManager()
        
    def load_data(self) -> None:
        """Load data from JSON file."""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                    self.expenses = data.get('expenses', [])
                    self.budgets = data.get('budgets', {})
                    self.income_entries = data.get('income_entries', [])
                    self.savings_goals = data.get('savings_goals', {})
            except json.JSONDecodeError:
                self._initialize_empty_data()
        else:
            self._initialize_empty_data()
            
    def _initialize_empty_data(self) -> None:
        """Initialize empty data structures."""
        self.expenses = []
        self.budgets = {}
        self.income_entries = []
        self.savings_goals = {}
            
    def save_data(self) -> None:
        """Save data to JSON file."""
        data = {
            'expenses': self.expenses,
            'budgets': self.budgets,
            'income_entries': self.income_entries,
            'savings_goals': self.savings_goals
        }
        with open(self.data_file, 'w') as f:
            json.dump(data, f, indent=2)
            
    def add_expense(self, date: str, amount: float, category: str, 
                   description: str, transaction_type: str = "expense") -> None:
        """
        Add a new expense or income entry.
        
        Args:
            date: Date of the transaction (YYYY-MM-DD format)
            amount: Amount of the transaction
            category: Category in format "MainCategory:Subcategory"
            description: Description of the transaction
            transaction_type: Type of transaction ("expense", "income", "savings")
        """
        transaction = {
            'date': date,
            'amount': amount,
            'category': category,
            'description': description,
            'type': transaction_type
        }
        
        # Determine which list to add to based on category or type
        main_category, _ = self.category_manager.parse_category_string(category)
        
        if (transaction_type == "income" or 
            self.category_manager.is_income_category(main_category)):
            self.income_entries.append(transaction)
        else:
            self.expenses.append(transaction)
            
        self.save_data()
        
    def delete_expense(self, index: int, transaction_type: str = "expense") -> bool:
        """
        Delete a transaction by index.
        
        Args:
            index: Index of the transaction to delete
            transaction_type: Type of transaction to delete from
            
        Returns:
            True if deletion was successful, False otherwise
        """
        if transaction_type == "income":
            if 0 <= index < len(self.income_entries):
                del self.income_entries[index]
                self.save_data()
                return True
        else:
            if 0 <= index < len(self.expenses):
                del self.expenses[index]
                self.save_data()
                return True
        return False
        
    def set_budget(self, category: str, amount: float) -> None:
        """
        Set budget for a category.
        
        Args:
            category: Budget category (can include subcategory)
            amount: Budget amount
        """
        self.budgets[category] = amount
        self.save_data()
        
    def set_savings_goal(self, goal_name: str, amount: float) -> None:
        """
        Set a savings goal.
        
        Args:
            goal_name: Name of the savings goal
            amount: Target amount for the goal
        """
        self.savings_goals[goal_name] = amount
        self.save_data()
        
    def get_expenses(self) -> List[Dict[str, Any]]:
        """Get all expenses."""
        return self.expenses.copy()
        
    def get_income_entries(self) -> List[Dict[str, Any]]:
        """Get all income entries."""
        return self.income_entries.copy()
        
    def get_budgets(self) -> Dict[str, float]:
        """Get all budgets."""
        return self.budgets.copy()
        
    def get_savings_goals(self) -> Dict[str, float]:
        """Get all savings goals."""
        return self.savings_goals.copy()
        
    def get_categories(self) -> set:
        """Get all unique expense categories."""
        all_categories = set()
        for expense in self.expenses:
            all_categories.add(expense['category'])
        for income in self.income_entries:
            all_categories.add(income['category'])
        return all_categories
        
    def get_main_categories_used(self) -> set:
        """Get all unique main categories that have been used."""
        main_categories = set()
        for expense in self.expenses:
            main_cat, _ = self.category_manager.parse_category_string(
                expense['category']
            )
            main_categories.add(main_cat)
        for income in self.income_entries:
            main_cat, _ = self.category_manager.parse_category_string(
                income['category']
            )
            main_categories.add(main_cat)
        return main_categories
        
    def get_monthly_totals(self, month: str = None) -> Dict[str, float]:
        """
        Get monthly totals for income, expenses, and savings.
        
        Args:
            month: Month in YYYY-MM format (defaults to current month)
            
        Returns:
            Dictionary with monthly totals
        """
        from ..utils.helpers import filter_expenses_by_month, get_current_month
        
        if month is None:
            month = get_current_month()
            
        monthly_expenses = filter_expenses_by_month(self.expenses, month)
        monthly_income = filter_expenses_by_month(self.income_entries, month)
        
        expense_total = sum(exp['amount'] for exp in monthly_expenses)
        income_total = sum(inc['amount'] for inc in monthly_income)
        
        # Calculate savings as income - expenses
        savings_actual = income_total - expense_total
        
        return {
            'income': income_total,
            'expenses': expense_total,
            'savings': savings_actual,
            'net': savings_actual
        }
