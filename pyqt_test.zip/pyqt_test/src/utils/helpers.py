"""
Utility Functions Module
Contains helper functions for formatting, calculations, and common operations.
"""

from datetime import datetime
from typing import List, Dict, Any, Tuple
from .categories import CategoryManager


def format_currency(amount: float) -> str:
    """
    Format a float amount as currency string.
    
    Args:
        amount: The amount to format
        
    Returns:
        Formatted currency string
    """
    return f"${amount:.2f}"


def get_current_month() -> str:
    """
    Get current month in YYYY-MM format.
    
    Returns:
        Current month string
    """
    return datetime.now().strftime("%Y-%m")


def filter_expenses_by_month(expenses: List[Dict[str, Any]], 
                           month: str = None) -> List[Dict[str, Any]]:
    """
    Filter expenses by month.
    
    Args:
        expenses: List of expense dictionaries
        month: Month string in YYYY-MM format (defaults to current month)
        
    Returns:
        Filtered list of expenses
    """
    if month is None:
        month = get_current_month()
    
    return [exp for exp in expenses if exp['date'].startswith(month)]


def calculate_category_totals(expenses: List[Dict[str, Any]]) -> Dict[str, float]:
    """
    Calculate total spending by category.
    
    Args:
        expenses: List of expense dictionaries
        
    Returns:
        Dictionary with category totals
    """
    category_totals = {}
    for expense in expenses:
        category = expense['category']
        if category in category_totals:
            category_totals[category] += expense['amount']
        else:
            category_totals[category] = expense['amount']
    return category_totals


def calculate_subcategory_totals(expenses: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    """
    Calculate total spending by category and subcategory.
    
    Args:
        expenses: List of expense dictionaries
        
    Returns:
        Nested dictionary with category and subcategory totals
    """
    category_manager = CategoryManager()
    totals = {}
    
    for expense in expenses:
        category_string = expense.get('category', 'Other:Other')
        main_category, subcategory = category_manager.parse_category_string(category_string)
        
        if main_category not in totals:
            totals[main_category] = {}
        
        if subcategory not in totals[main_category]:
            totals[main_category][subcategory] = 0
            
        totals[main_category][subcategory] += expense['amount']
    
    return totals


def calculate_budget_percentage(spent: float, budget: float) -> float:
    """
    Calculate percentage of budget used.
    
    Args:
        spent: Amount spent
        budget: Budget amount
        
    Returns:
        Percentage of budget used (capped at 100)
    """
    if budget <= 0:
        return 0
    return min((spent / budget) * 100, 100)


def calculate_zero_based_budget(income: float, expenses: List[Dict[str, Any]], 
                              budgets: Dict[str, float]) -> Dict[str, Any]:
    """
    Calculate zero-based budget analysis.
    
    Args:
        income: Total monthly income
        expenses: List of expense dictionaries
        budgets: Dictionary of category budgets
        
    Returns:
        Dictionary with budget analysis data
    """
    category_manager = CategoryManager()
    current_expenses = filter_expenses_by_month(expenses)
    
    # Separate income and expense transactions
    income_total = sum(exp['amount'] for exp in current_expenses 
                      if category_manager.is_income_category(
                          category_manager.parse_category_string(exp['category'])[0]
                      ))
    
    expense_total = sum(exp['amount'] for exp in current_expenses 
                       if not category_manager.is_income_category(
                           category_manager.parse_category_string(exp['category'])[0]
                       ))
    
    savings_allocated = sum(exp['amount'] for exp in current_expenses 
                           if category_manager.is_savings_category(
                               category_manager.parse_category_string(exp['category'])[0]
                           ))
    
    total_budgeted = sum(budgets.values())
    unallocated = income_total - total_budgeted
    
    return {
        'income_total': income_total,
        'expense_total': expense_total,
        'savings_allocated': savings_allocated,
        'total_budgeted': total_budgeted,
        'unallocated': unallocated,
        'balance': income_total - expense_total,
        'budget_vs_actual': total_budgeted - expense_total
    }


def get_default_categories() -> List[str]:
    """
    Get list of default expense categories with subcategories.
    
    Returns:
        List of formatted category:subcategory strings
    """
    category_manager = CategoryManager()
    return category_manager.get_formatted_category_list()


def get_main_categories() -> List[str]:
    """
    Get list of main categories only.
    
    Returns:
        List of main categories
    """
    category_manager = CategoryManager()
    return category_manager.get_all_categories()


def get_subcategories_for_category(category: str) -> List[str]:
    """
    Get subcategories for a specific main category.
    
    Args:
        category: Main category name
        
    Returns:
        List of subcategories
    """
    category_manager = CategoryManager()
    return category_manager.get_subcategories(category)
