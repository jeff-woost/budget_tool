"""
Categories Module
Manages budget categories and subcategories for zero-based budgeting.
"""

from typing import Dict, List, Tuple, Set


class CategoryManager:
    """Manages categories and subcategories for budget tracking."""
    
    def __init__(self):
        """Initialize the category manager with predefined categories."""
        self._categories = self._load_categories()
        
    def _load_categories(self) -> Dict[str, List[str]]:
        """Load categories and subcategories from predefined data."""
        return {
            "Income": [
                "Salary",
                "Freelance",
                "Investment Returns",
                "Rental Income",
                "Side Business",
                "Tax Refund",
                "Gifts Received",
                "Other Income"
            ],
            "Housing": [
                "Special Assessment",
                "Additional Principal",
                "Lima Apartment Wires",
                "Lima Apartment Fees",
                "Escrow",
                "HOA",
                "Reserves",
                "Condo Insurance",
                "Property Taxes",
                "Labor",
                "Rent/Mortgage",
                "Utilities"
            ],
            "Utilities": [
                "Optimum",
                "PSEG",
                "Cell Phone",
                "Car Insurance",
                "Gloria",
                "Insurance",
                "Taxi / Transit",
                "Bus Pass",
                "Misc Utility",
                "Electricity",
                "Gas",
                "Water",
                "Internet",
                "Trash"
            ],
            "Food": [
                "Groceries",
                "Take Out",
                "Dining Out",
                "Party",
                "Guests",
                "Work",
                "Special Occasion",
                "Other"
            ],
            "Healthcare": [
                "Jeff Doctor",
                "Prescriptions",
                "Vitamins",
                "Other Doctor Visits",
                "Haircut",
                "Hygenie",
                "Family",
                "Fertility",
                "Co-Pay",
                "Baker",
                "HC Subscriptions",
                "Joaquin Health Care",
                "Zoe Health Care",
                "Misc Health Care",
                "Dental",
                "Vision"
            ],
            "Childcare": [
                "Village Classes",
                "Baby Sitting",
                "Clothing",
                "Diapers",
                "Necessities",
                "Accessories",
                "Toys",
                "Food / Snacks",
                "Haircut",
                "Activities",
                "Uber / Lyft",
                "Misc.",
                "School Supplies",
                "Tuition"
            ],
            "Vehicles": [
                "Vehicle Fixes",
                "Vehicle Other",
                "Gas",
                "DMV",
                "Parts",
                "Tires / Wheels",
                "Insurance",
                "Oil Changes",
                "Car Wash",
                "Parking",
                "Tolls",
                "Registration",
                "Car Payment"
            ],
            "Home": [
                "Home Necessities",
                "Home Décor",
                "House Cleaning",
                "Bathroom",
                "Bedrooms",
                "Kitchen",
                "Tools / Hardware",
                "Storage",
                "Homeware",
                "Subscriptions",
                "Maintenance",
                "Repairs"
            ],
            "Personal": [
                "Gifts",
                "Clothes",
                "Shoes",
                "Personal Care",
                "Hobbies",
                "Education",
                "Books",
                "Subscriptions"
            ],
            "Entertainment": [
                "Movies",
                "Concerts",
                "Sports Events",
                "Streaming Services",
                "Games",
                "Books",
                "Other Entertainment"
            ],
            "Vacation": [
                "Flights/Travel",
                "Rental Car",
                "Airport",
                "Taxi",
                "Food",
                "Eating Out",
                "Gas",
                "Activities",
                "Bedding",
                "Fees",
                "Physical Goods",
                "Housing",
                "Necessities"
            ],
            "Debt Payments": [
                "Credit Cards",
                "Student Loans",
                "Personal Loans",
                "Auto Loans",
                "Other Debt"
            ],
            "Savings Goals": [
                "Emergency Fund",
                "Retirement",
                "Vacation Fund",
                "House Down Payment",
                "Car Replacement",
                "Education Fund",
                "Investment Account",
                "Other Savings"
            ],
            "Taxes & Fees": [
                "Income Tax",
                "Property Tax",
                "Sales Tax",
                "Bank Fees",
                "Service Fees",
                "Late Fees",
                "Other Taxes"
            ],
            "Charitable Giving": [
                "Religious Organizations",
                "Charities",
                "Non-Profits",
                "Community Groups",
                "Other Donations"
            ],
            "Pets": [
                "Pet Food",
                "Veterinary",
                "Pet Supplies",
                "Pet Insurance",
                "Grooming",
                "Pet Care"
            ],
            "Other": [
                "Target AutoPay",
                "Stupid Tax",
                "Amazon Prime",
                "Fees",
                "Reversal",
                "Gatherings",
                "Parties",
                "Miscellaneous"
            ]
        }
    
    def get_all_categories(self) -> List[str]:
        """Get list of all main categories."""
        return list(self._categories.keys())
    
    def get_subcategories(self, category: str) -> List[str]:
        """Get subcategories for a given category."""
        return self._categories.get(category, [])
    
    def get_category_subcategory_pairs(self) -> List[Tuple[str, str]]:
        """Get all category:subcategory pairs."""
        pairs = []
        for category, subcategories in self._categories.items():
            for subcategory in subcategories:
                pairs.append((category, subcategory))
        return pairs
    
    def get_formatted_category_list(self) -> List[str]:
        """Get formatted list of category:subcategory strings."""
        formatted = []
        for category, subcategories in self._categories.items():
            for subcategory in subcategories:
                formatted.append(f"{category}:{subcategory}")
        return sorted(formatted)
    
    def parse_category_string(self, category_string: str) -> Tuple[str, str]:
        """
        Parse a category:subcategory string.
        
        Args:
            category_string: String in format "Category:Subcategory"
            
        Returns:
            Tuple of (category, subcategory)
        """
        if ":" in category_string:
            parts = category_string.split(":", 1)
            return (parts[0].strip(), parts[1].strip())
        else:
            # If no subcategory specified, use "General" as default
            return (category_string.strip(), "General")
    
    def is_income_category(self, category: str) -> bool:
        """Check if a category is an income category."""
        return category == "Income"
    
    def is_savings_category(self, category: str) -> bool:
        """Check if a category is a savings category."""
        return category == "Savings Goals"
    
    def get_expense_categories(self) -> List[str]:
        """Get categories that are expenses (not income or savings)."""
        return [cat for cat in self.get_all_categories() 
                if not self.is_income_category(cat) and not self.is_savings_category(cat)]
    
    def add_custom_subcategory(self, category: str, subcategory: str) -> bool:
        """
        Add a custom subcategory to an existing category.
        
        Args:
            category: Main category name
            subcategory: New subcategory name
            
        Returns:
            True if added successfully, False if category doesn't exist
        """
        if category in self._categories:
            if subcategory not in self._categories[category]:
                self._categories[category].append(subcategory)
                return True
        return False
