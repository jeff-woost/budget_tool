"""
GUI Components Package
Contains all user interface related classes and components.
"""
