"""
Tab Components Package
Contains individual tab widgets for the main application.
"""
