"""
Spending Tab Module
Contains the spending/expense tracking tab widget with subcategory support.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QGridLayout, QLabel,
    QDateEdit, QDoubleSpinBox, QComboBox, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QMessageBox, QHeaderView,
    QHBoxLayout, QRadioButton, QButtonGroup, QFileDialog, QDialog,
    QDialogButtonBox, QTextEdit, QProgressBar
)
from PyQt6.QtCore import QDate, pyqtSignal
import csv
import os
from datetime import datetime

from ...data.data_manager import DataManager
from ...utils.helpers import get_default_categories, get_main_categories
from ...utils.categories import CategoryManager


class SpendingTab(QWidget):
    """Widget for managing expenses and income tracking with subcategories."""
    
    data_changed = pyqtSignal()
    
    def __init__(self, data_manager: DataManager):
        super().__init__()
        self.data_manager = data_manager
        self.category_manager = CategoryManager()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the spending tab user interface."""
        layout = QVBoxLayout(self)
        
        # Add transaction section
        transaction_group = QGroupBox("Add New Transaction")
        transaction_layout = QGridLayout(transaction_group)
        
        # Transaction type selection
        transaction_layout.addWidget(QLabel("Type:"), 0, 0)
        type_layout = QHBoxLayout()
        
        self.transaction_type_group = QButtonGroup()
        self.expense_radio = QRadioButton("Expense")
        self.income_radio = QRadioButton("Income")
        self.savings_radio = QRadioButton("Savings")
        
        self.expense_radio.setChecked(True)  # Default to expense
        
        self.transaction_type_group.addButton(self.expense_radio, 0)
        self.transaction_type_group.addButton(self.income_radio, 1)
        self.transaction_type_group.addButton(self.savings_radio, 2)
        
        type_layout.addWidget(self.expense_radio)
        type_layout.addWidget(self.income_radio)
        type_layout.addWidget(self.savings_radio)
        type_layout.addStretch()
        
        transaction_layout.addLayout(type_layout, 0, 1, 1, 3)
        
        # Date input
        transaction_layout.addWidget(QLabel("Date:"), 1, 0)
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        transaction_layout.addWidget(self.date_edit, 1, 1)
        
        # Amount input
        transaction_layout.addWidget(QLabel("Amount:"), 1, 2)
        self.amount_input = QDoubleSpinBox()
        self.amount_input.setMaximum(99999.99)
        self.amount_input.setPrefix("$")
        transaction_layout.addWidget(self.amount_input, 1, 3)
        
        # Main category input
        transaction_layout.addWidget(QLabel("Main Category:"), 2, 0)
        self.main_category_combo = QComboBox()
        transaction_layout.addWidget(self.main_category_combo, 2, 1)
        
        # Subcategory input
        transaction_layout.addWidget(QLabel("Subcategory:"), 2, 2)
        self.subcategory_combo = QComboBox()
        self.subcategory_combo.setEditable(True)
        transaction_layout.addWidget(self.subcategory_combo, 2, 3)
        
        # Now connect the signal after both combos are created
        self.main_category_combo.currentTextChanged.connect(
            self.on_main_category_changed
        )
        
        # Description input
        transaction_layout.addWidget(QLabel("Description:"), 3, 0)
        self.description_input = QLineEdit()
        transaction_layout.addWidget(self.description_input, 3, 1, 1, 3)
        
        # Add button
        add_button = QPushButton("Add Transaction")
        add_button.clicked.connect(self.add_transaction)
        transaction_layout.addWidget(add_button, 4, 0, 1, 2)
        
        # CSV Upload button
        csv_upload_button = QPushButton("📁 Upload CSV")
        csv_upload_button.setObjectName("csv_upload_button")
        csv_upload_button.clicked.connect(self.upload_csv)
        transaction_layout.addWidget(csv_upload_button, 4, 2, 1, 2)
        
        layout.addWidget(transaction_group)
        
        # Transactions table
        self.transactions_table = QTableWidget()
        self.transactions_table.setColumnCount(6)
        self.transactions_table.setHorizontalHeaderLabels([
            "Date", "Type", "Amount", "Category", "Description", "Actions"
        ])
        header = self.transactions_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.transactions_table)
        
        # Update displays
        self.update_main_category_combo()
        self.update_subcategory_combo()  # Initialize subcategory combo
        self.update_transactions_table()
        
    def on_main_category_changed(self):
        """Handle main category selection change."""
        main_category = self.main_category_combo.currentText()
        self.update_subcategory_combo(main_category)
        
    def update_main_category_combo(self):
        """Update main category combo box."""
        current_text = self.main_category_combo.currentText()
        self.main_category_combo.clear()
        
        categories = get_main_categories()
        self.main_category_combo.addItems(categories)
        
        if current_text:
            self.main_category_combo.setCurrentText(current_text)
        else:
            # Default to "Food" or first category
            if "Food" in categories:
                self.main_category_combo.setCurrentText("Food")
                
    def update_subcategory_combo(self, main_category: str = None):
        """Update subcategory combo box based on main category selection."""
        if main_category is None:
            main_category = self.main_category_combo.currentText()
            
        current_text = self.subcategory_combo.currentText()
        self.subcategory_combo.clear()
        
        if main_category:
            subcategories = self.category_manager.get_subcategories(main_category)
            self.subcategory_combo.addItems(subcategories)
            
        if current_text:
            self.subcategory_combo.setCurrentText(current_text)
        
    def add_transaction(self):
        """Add a new transaction (expense or income)."""
        date = self.date_edit.date().toString("yyyy-MM-dd")
        amount = self.amount_input.value()
        main_category = self.main_category_combo.currentText().strip()
        subcategory = self.subcategory_combo.currentText().strip()
        description = self.description_input.text().strip()
        
        # Determine transaction type
        if self.income_radio.isChecked():
            transaction_type = "income"
        elif self.savings_radio.isChecked():
            transaction_type = "savings"
        else:
            transaction_type = "expense"
        
        if amount <= 0:
            QMessageBox.warning(
                self, "Invalid Amount",
                "Please enter a valid amount greater than 0."
            )
            return
            
        if not main_category:
            QMessageBox.warning(
                self, "Missing Category", "Please select a main category."
            )
            return
            
        if not subcategory:
            QMessageBox.warning(
                self, "Missing Subcategory", "Please select or enter a subcategory."
            )
            return
        
        # Format category as "MainCategory:Subcategory"
        full_category = f"{main_category}:{subcategory}"
        
        # Add transaction through data manager
        self.data_manager.add_expense(
            date, amount, full_category, description, transaction_type
        )
        
        # Clear inputs
        self.amount_input.setValue(0)
        self.description_input.clear()
        # Reset to first subcategory
        if self.subcategory_combo.count() > 0:
            self.subcategory_combo.setCurrentIndex(0)
        
        # Update displays and emit signal
        self.update_transactions_table()
        self.data_changed.emit()
        
        type_name = transaction_type.capitalize()
        QMessageBox.information(
            self, "Success", f"{type_name} added successfully!"
        )
        
    def update_transactions_table(self):
        """Update the transactions table with both expenses and income."""
        expenses = self.data_manager.get_expenses()
        income_entries = self.data_manager.get_income_entries()
        
        # Combine and sort by date (most recent first)
        all_transactions = []
        
        for exp in expenses:
            exp_copy = exp.copy()
            exp_copy['type'] = exp_copy.get('type', 'expense')
            all_transactions.append(exp_copy)
            
        for inc in income_entries:
            inc_copy = inc.copy()
            inc_copy['type'] = inc_copy.get('type', 'income')
            all_transactions.append(inc_copy)
            
        # Sort by date (newest first)
        all_transactions.sort(key=lambda x: x['date'], reverse=True)
        
        self.transactions_table.setRowCount(len(all_transactions))
        
        for row, transaction in enumerate(all_transactions):
            self.transactions_table.setItem(
                row, 0, QTableWidgetItem(transaction['date'])
            )
            
            transaction_type = transaction.get('type', 'expense').capitalize()
            type_item = QTableWidgetItem(transaction_type)
            self.transactions_table.setItem(row, 1, type_item)
            
            amount_text = f"${transaction['amount']:.2f}"
            if transaction_type.lower() == 'income':
                amount_text = f"+{amount_text}"
            self.transactions_table.setItem(
                row, 2, QTableWidgetItem(amount_text)
            )
            
            self.transactions_table.setItem(
                row, 3, QTableWidgetItem(transaction['category'])
            )
            self.transactions_table.setItem(
                row, 4, QTableWidgetItem(transaction['description'])
            )
            
            # Add delete button
            delete_button = QPushButton("🗑️ Delete")
            delete_button.setObjectName("delete_button")
            delete_button.clicked.connect(
                lambda checked, r=row, t=transaction: self.delete_transaction(r, t)
            )
            self.transactions_table.setCellWidget(row, 5, delete_button)
            
    def delete_transaction(self, row, transaction):
        """Delete a transaction."""
        reply = QMessageBox.question(
            self, "Confirm Delete",
            "Are you sure you want to delete this transaction?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            transaction_type = transaction.get('type', 'expense')
            
            # Find the actual index in the respective list
            if transaction_type == 'income':
                income_entries = self.data_manager.get_income_entries()
                for i, entry in enumerate(income_entries):
                    if (entry['date'] == transaction['date'] and
                        entry['amount'] == transaction['amount'] and
                        entry['category'] == transaction['category'] and
                        entry['description'] == transaction['description']):
                        self.data_manager.delete_expense(i, "income")
                        break
            else:
                expenses = self.data_manager.get_expenses()
                for i, expense in enumerate(expenses):
                    if (expense['date'] == transaction['date'] and
                        expense['amount'] == transaction['amount'] and
                        expense['category'] == transaction['category'] and
                        expense['description'] == transaction['description']):
                        self.data_manager.delete_expense(i, "expense")
                        break
            
            self.update_transactions_table()
            self.data_changed.emit()
    
    def upload_csv(self):
        """Upload and process CSV file for bulk expense import."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select CSV File",
            "",
            "CSV Files (*.csv);;All Files (*)"
        )
        
        if not file_path:
            return
            
        try:
            # Read CSV file
            transactions_to_import = []
            
            with open(file_path, 'r', newline='', encoding='utf-8') as csvfile:
                # Try to detect delimiter
                sample = csvfile.read(1024)
                csvfile.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                reader = csv.DictReader(csvfile, delimiter=delimiter)
                
                # Check if required columns exist
                required_columns = ['Transaction Date', 'Description', 'Amount']
                missing_columns = [col for col in required_columns if col not in reader.fieldnames]
                
                if missing_columns:
                    QMessageBox.warning(
                        self,
                        "Missing Columns",
                        f"The CSV file is missing required columns: {', '.join(missing_columns)}\n"
                        f"Required columns: {', '.join(required_columns)}"
                    )
                    return
                
                # Process each row
                for row_num, row in enumerate(reader, 1):
                    try:
                        # Parse date
                        date_str = row['Transaction Date'].strip()
                        if date_str:
                            # Try different date formats
                            date_formats = ['%m/%d/%y', '%m/%d/%Y', '%Y-%m-%d', '%d/%m/%Y']
                            parsed_date = None
                            
                            for date_format in date_formats:
                                try:
                                    parsed_date = datetime.strptime(date_str, date_format)
                                    break
                                except ValueError:
                                    continue
                            
                            if parsed_date is None:
                                continue  # Skip rows with invalid dates
                            
                            formatted_date = parsed_date.strftime('%Y-%m-%d')
                        else:
                            continue  # Skip rows without dates
                        
                        # Parse amount (multiply by -1 to make expenses positive)
                        amount_str = row['Amount'].strip()
                        if amount_str:
                            # Remove currency symbols and commas
                            amount_str = amount_str.replace('$', '').replace(',', '')
                            try:
                                amount = abs(float(amount_str))  # Make positive for expenses
                                if amount <= 0:
                                    continue  # Skip zero or negative amounts
                            except ValueError:
                                continue  # Skip rows with invalid amounts
                        else:
                            continue  # Skip rows without amounts
                        
                        # Get description
                        description = row['Description'].strip()
                        if not description:
                            description = "Imported transaction"
                        
                        transaction = {
                            'date': formatted_date,
                            'amount': amount,
                            'description': description
                        }
                        
                        transactions_to_import.append(transaction)
                        
                    except Exception as e:
                        print(f"Error processing row {row_num}: {e}")
                        continue
            
            if not transactions_to_import:
                QMessageBox.information(
                    self,
                    "No Valid Transactions",
                    "No valid transactions were found in the CSV file."
                )
                return
            
            # Show categorization dialog
            self.show_categorization_dialog(transactions_to_import)
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "CSV Import Error",
                f"An error occurred while importing the CSV file:\n{str(e)}"
            )
    
    def show_categorization_dialog(self, transactions):
        """Show dialog for categorizing imported transactions."""
        dialog = CSVCategorizationDialog(transactions, self.category_manager, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            categorized_transactions = dialog.get_categorized_transactions()
            
            # Add transactions to data manager
            success_count = 0
            for transaction in categorized_transactions:
                try:
                    self.data_manager.add_expense(
                        transaction['date'],
                        transaction['amount'],
                        transaction['category'],
                        transaction['description'],
                        transaction_type='expense'
                    )
                    success_count += 1
                except Exception as e:
                    print(f"Error adding transaction: {e}")
            
            # Update display
            self.update_transactions_table()
            self.data_changed.emit()
            
            QMessageBox.information(
                self,
                "Import Complete",
                f"Successfully imported {success_count} out of {len(transactions)} transactions."
            )


class CSVCategorizationDialog(QDialog):
    """Dialog for categorizing imported CSV transactions."""
    
    def __init__(self, transactions, category_manager, parent=None):
        super().__init__(parent)
        self.transactions = transactions
        self.category_manager = category_manager
        self.categorized_transactions = []
        self.init_ui()
        
    def init_ui(self):
        """Initialize the categorization dialog UI."""
        self.setWindowTitle("Categorize Imported Transactions")
        self.setGeometry(200, 200, 800, 600)
        
        layout = QVBoxLayout(self)
        
        # Instructions
        instructions = QLabel(
            "Please categorize the imported transactions. "
            "You can assign categories to multiple transactions at once by selecting similar descriptions."
        )
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Transaction table
        self.transaction_table = QTableWidget()
        self.transaction_table.setColumnCount(5)
        self.transaction_table.setHorizontalHeaderLabels([
            "Date", "Amount", "Description", "Main Category", "Subcategory"
        ])
        self.transaction_table.setRowCount(len(self.transactions))
        
        # Populate table
        for row, transaction in enumerate(self.transactions):
            self.transaction_table.setItem(row, 0, QTableWidgetItem(transaction['date']))
            self.transaction_table.setItem(row, 1, QTableWidgetItem(f"${transaction['amount']:.2f}"))
            self.transaction_table.setItem(row, 2, QTableWidgetItem(transaction['description']))
            
            # Main category combo
            main_category_combo = QComboBox()
            main_categories = self.category_manager.get_main_categories()
            main_category_combo.addItems([""] + main_categories)
            main_category_combo.currentTextChanged.connect(
                lambda text, r=row: self.on_main_category_changed(r, text)
            )
            self.transaction_table.setCellWidget(row, 3, main_category_combo)
            
            # Subcategory combo
            subcategory_combo = QComboBox()
            subcategory_combo.setEditable(True)
            self.transaction_table.setCellWidget(row, 4, subcategory_combo)
        
        self.transaction_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.transaction_table)
        
        # Auto-categorize button
        auto_categorize_button = QPushButton("Auto-Categorize Similar Descriptions")
        auto_categorize_button.clicked.connect(self.auto_categorize)
        layout.addWidget(auto_categorize_button)
        
        # Dialog buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
    
    def on_main_category_changed(self, row, main_category):
        """Handle main category change in categorization dialog."""
        if main_category:
            subcategory_combo = self.transaction_table.cellWidget(row, 4)
            subcategories = self.category_manager.get_subcategories(main_category)
            subcategory_combo.clear()
            subcategory_combo.addItems([""] + subcategories)
    
    def auto_categorize(self):
        """Attempt to auto-categorize transactions based on description keywords."""
        # Simple keyword-based categorization
        keyword_mappings = {
            'grocery': ('Food', 'Groceries'),
            'gas': ('Transportation', 'Gas'),
            'restaurant': ('Food', 'Dining Out'),
            'coffee': ('Food', 'Coffee/Tea'),
            'uber': ('Transportation', 'Rideshare'),
            'amazon': ('Shopping', 'Online Shopping'),
            'walmart': ('Shopping', 'General Merchandise'),
            'netflix': ('Entertainment', 'Streaming Services'),
            'spotify': ('Entertainment', 'Music'),
            'gym': ('Health', 'Fitness'),
            'pharmacy': ('Health', 'Pharmacy'),
            'doctor': ('Health', 'Medical'),
        }
        
        categorized_count = 0
        
        for row in range(self.transaction_table.rowCount()):
            description = self.transaction_table.item(row, 2).text().lower()
            main_category_combo = self.transaction_table.cellWidget(row, 3)
            subcategory_combo = self.transaction_table.cellWidget(row, 4)
            
            # Skip if already categorized
            if main_category_combo.currentText():
                continue
            
            # Find matching keywords
            for keyword, (main_cat, sub_cat) in keyword_mappings.items():
                if keyword in description:
                    main_category_combo.setCurrentText(main_cat)
                    self.on_main_category_changed(row, main_cat)
                    subcategory_combo.setCurrentText(sub_cat)
                    categorized_count += 1
                    break
        
        QMessageBox.information(
            self,
            "Auto-Categorization Complete",
            f"Automatically categorized {categorized_count} transactions."
        )
    
    def get_categorized_transactions(self):
        """Get the categorized transactions from the dialog."""
        categorized = []
        
        for row in range(self.transaction_table.rowCount()):
            main_category_combo = self.transaction_table.cellWidget(row, 3)
            subcategory_combo = self.transaction_table.cellWidget(row, 4)
            
            main_category = main_category_combo.currentText()
            subcategory = subcategory_combo.currentText()
            
            if main_category and subcategory:
                category = f"{main_category}:{subcategory}"
            elif main_category:
                category = main_category
            else:
                category = "Other:Uncategorized"
            
            transaction = {
                'date': self.transactions[row]['date'],
                'amount': self.transactions[row]['amount'],
                'description': self.transactions[row]['description'],
                'category': category
            }
            categorized.append(transaction)
        
        return categorized
