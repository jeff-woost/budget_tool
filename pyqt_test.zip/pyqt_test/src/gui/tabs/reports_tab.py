"""
Reports Tab Module
Contains the reports and analytics tab widget.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QLabel,
    QTableWidget, QTableWidgetItem, QHeaderView
)

from ...data.data_manager import DataManager
from ...utils.helpers import (
    filter_expenses_by_month, calculate_category_totals, format_currency
)


class ReportsTab(QWidget):
    """Widget for viewing reports and spending analytics."""
    
    def __init__(self, data_manager: DataManager):
        super().__init__()
        self.data_manager = data_manager
        self.init_ui()
        
    def init_ui(self):
        """Initialize the reports tab user interface."""
        layout = QVBoxLayout(self)
        
        # Summary section
        summary_group = QGroupBox("Monthly Summary")
        summary_layout = QVBoxLayout(summary_group)
        
        self.total_spent_label = QLabel("Total Spent This Month: $0.00")
        self.total_budget_label = QLabel("Total Budget: $0.00")
        self.remaining_budget_label = QLabel("Remaining Budget: $0.00")
        
        summary_layout.addWidget(self.total_spent_label)
        summary_layout.addWidget(self.total_budget_label)
        summary_layout.addWidget(self.remaining_budget_label)
        
        layout.addWidget(summary_group)
        
        # Category breakdown
        breakdown_group = QGroupBox("Category Breakdown")
        self.breakdown_layout = QVBoxLayout(breakdown_group)
        layout.addWidget(breakdown_group)
        
        self.update_reports()
        
    def update_reports(self):
        """Update reports display."""
        # Clear existing widgets
        for i in reversed(range(self.breakdown_layout.count())):
            child = self.breakdown_layout.takeAt(i).widget()
            if child:
                child.setParent(None)
                
        # Get current month data
        expenses = self.data_manager.get_expenses()
        current_expenses = filter_expenses_by_month(expenses)
        budgets = self.data_manager.get_budgets()
        
        total_spent = sum(exp['amount'] for exp in current_expenses)
        total_budget = sum(budgets.values())
        remaining_budget = total_budget - total_spent
        
        # Update summary labels
        self.total_spent_label.setText(
            f"Total Spent This Month: {format_currency(total_spent)}"
        )
        self.total_budget_label.setText(
            f"Total Budget: {format_currency(total_budget)}"
        )
        self.remaining_budget_label.setText(
            f"Remaining Budget: {format_currency(remaining_budget)}"
        )
        
        # Color code remaining budget
        if remaining_budget < 0:
            self.remaining_budget_label.setStyleSheet(
                "color: #e74c3c; font-weight: bold;"
            )
        else:
            self.remaining_budget_label.setStyleSheet(
                "color: #27ae60; font-weight: bold;"
            )
            
        # Category breakdown
        category_totals = calculate_category_totals(current_expenses)
                
        if category_totals:
            breakdown_table = QTableWidget()
            breakdown_table.setColumnCount(3)
            breakdown_table.setHorizontalHeaderLabels([
                "Category", "Spent", "% of Total"
            ])
            breakdown_table.setRowCount(len(category_totals))
            
            sorted_categories = sorted(
                category_totals.items(), key=lambda x: x[1], reverse=True
            )
            
            for row, (category, amount) in enumerate(sorted_categories):
                percentage = (
                    (amount / total_spent) * 100 if total_spent > 0 else 0
                )
                
                breakdown_table.setItem(
                    row, 0, QTableWidgetItem(category)
                )
                breakdown_table.setItem(
                    row, 1, QTableWidgetItem(format_currency(amount))
                )
                breakdown_table.setItem(
                    row, 2, QTableWidgetItem(f"{percentage:.1f}%")
                )
                
            header = breakdown_table.horizontalHeader()
            header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            self.breakdown_layout.addWidget(breakdown_table)
        else:
            no_data_label = QLabel("No expenses recorded for this month.")
            self.breakdown_layout.addWidget(no_data_label)
            
    def refresh_data(self):
        """Refresh the tab data display."""
        self.update_reports()
