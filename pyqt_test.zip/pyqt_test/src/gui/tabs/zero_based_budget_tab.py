"""
Zero-Based Budget Tab Module
Contains the zero-based budget management tab widget with income and savings goals.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QGridLayout, QLabel,
    QComboBox, QDoubleSpinBox, QPushButton, QProgressBar, QMessageBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget
)
from PyQt6.QtCore import pyqtSignal

from ...data.data_manager import DataManager
from ...utils.helpers import (
    get_main_categories, filter_expenses_by_month,
    calculate_budget_percentage, format_currency
)
from ...utils.categories import CategoryManager


class ZeroBasedBudgetTab(QWidget):
    """Widget for zero-based budget management with income and savings goals."""
    
    data_changed = pyqtSignal()
    
    def __init__(self, data_manager: DataManager):
        super().__init__()
        self.data_manager = data_manager
        self.category_manager = CategoryManager()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the zero-based budget tab user interface."""
        layout = QVBoxLayout(self)
        
        # Create sub-tabs for budget sections
        tab_widget = QTabWidget()
        
        # Income Planning Tab
        income_tab = self.create_income_tab()
        tab_widget.addTab(income_tab, "Income Planning")
        
        # Budget Allocation Tab
        budget_tab = self.create_budget_allocation_tab()
        tab_widget.addTab(budget_tab, "Budget Allocation")
        
        # Savings Goals Tab
        savings_tab = self.create_savings_goals_tab()
        tab_widget.addTab(savings_tab, "Savings Goals")
        
        # Overview Tab
        overview_tab = self.create_overview_tab()
        tab_widget.addTab(overview_tab, "Zero-Based Overview")
        
        layout.addWidget(tab_widget)
        
    def create_income_tab(self):
        """Create the income planning tab."""
        income_widget = QWidget()
        layout = QVBoxLayout(income_widget)
        
        # Expected Income Section
        income_group = QGroupBox("Monthly Income Planning")
        income_layout = QGridLayout(income_group)
        
        income_layout.addWidget(QLabel("Income Source:"), 0, 0)
        self.income_source_combo = QComboBox()
        self.income_source_combo.setEditable(True)
        income_sources = self.category_manager.get_subcategories("Income")
        self.income_source_combo.addItems(income_sources)
        income_layout.addWidget(self.income_source_combo, 0, 1)
        
        income_layout.addWidget(QLabel("Expected Amount:"), 0, 2)
        self.income_amount_input = QDoubleSpinBox()
        self.income_amount_input.setMaximum(999999.99)
        self.income_amount_input.setPrefix("$")
        income_layout.addWidget(self.income_amount_input, 0, 3)
        
        add_income_button = QPushButton("Add Income Source")
        add_income_button.clicked.connect(self.add_income_source)
        income_layout.addWidget(add_income_button, 1, 0, 1, 4)
        
        layout.addWidget(income_group)
        
        # Income Sources Table
        self.income_table = QTableWidget()
        self.income_table.setColumnCount(3)
        self.income_table.setHorizontalHeaderLabels([
            "Income Source", "Expected Amount", "Actions"
        ])
        header = self.income_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.income_table)
        
        return income_widget
        
    def create_budget_allocation_tab(self):
        """Create the budget allocation tab."""
        budget_widget = QWidget()
        layout = QVBoxLayout(budget_widget)
        
        # Budget Setup Section
        budget_group = QGroupBox("Category Budget Allocation")
        budget_layout = QGridLayout(budget_group)
        
        budget_layout.addWidget(QLabel("Main Category:"), 0, 0)
        self.budget_main_category_combo = QComboBox()
        expense_categories = self.category_manager.get_expense_categories()
        self.budget_main_category_combo.addItems(expense_categories)
        self.budget_main_category_combo.currentTextChanged.connect(
            self.on_budget_category_changed
        )
        budget_layout.addWidget(self.budget_main_category_combo, 0, 1)
        
        budget_layout.addWidget(QLabel("Subcategory:"), 0, 2)
        self.budget_subcategory_combo = QComboBox()
        self.budget_subcategory_combo.setEditable(True)
        budget_layout.addWidget(self.budget_subcategory_combo, 0, 3)
        
        budget_layout.addWidget(QLabel("Monthly Budget:"), 1, 0)
        self.budget_amount_input = QDoubleSpinBox()
        self.budget_amount_input.setMaximum(99999.99)
        self.budget_amount_input.setPrefix("$")
        budget_layout.addWidget(self.budget_amount_input, 1, 1)
        
        set_budget_button = QPushButton("Set Budget")
        set_budget_button.clicked.connect(self.set_budget)
        budget_layout.addWidget(set_budget_button, 1, 2, 1, 2)
        
        layout.addWidget(budget_group)
        
        # Budget Overview
        overview_group = QGroupBox("Budget vs Actual")
        self.budget_overview_layout = QVBoxLayout(overview_group)
        layout.addWidget(overview_group)
        
        return budget_widget
        
    def create_savings_goals_tab(self):
        """Create the savings goals tab."""
        savings_widget = QWidget()
        layout = QVBoxLayout(savings_widget)
        
        # Savings Goals Section
        savings_group = QGroupBox("Savings Goals")
        savings_layout = QGridLayout(savings_group)
        
        savings_layout.addWidget(QLabel("Savings Goal:"), 0, 0)
        self.savings_goal_combo = QComboBox()
        self.savings_goal_combo.setEditable(True)
        savings_goals = self.category_manager.get_subcategories("Savings Goals")
        self.savings_goal_combo.addItems(savings_goals)
        savings_layout.addWidget(self.savings_goal_combo, 0, 1)
        
        savings_layout.addWidget(QLabel("Monthly Target:"), 0, 2)
        self.savings_amount_input = QDoubleSpinBox()
        self.savings_amount_input.setMaximum(99999.99)
        self.savings_amount_input.setPrefix("$")
        savings_layout.addWidget(self.savings_amount_input, 0, 3)
        
        set_savings_button = QPushButton("Set Savings Goal")
        set_savings_button.clicked.connect(self.set_savings_goal)
        savings_layout.addWidget(set_savings_button, 1, 0, 1, 4)
        
        layout.addWidget(savings_group)
        
        # Savings Goals Table
        self.savings_table = QTableWidget()
        self.savings_table.setColumnCount(4)
        self.savings_table.setHorizontalHeaderLabels([
            "Savings Goal", "Monthly Target", "Progress", "Actions"
        ])
        header = self.savings_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.savings_table)
        
        return savings_widget
        
    def create_overview_tab(self):
        """Create the zero-based budget overview tab."""
        overview_widget = QWidget()
        layout = QVBoxLayout(overview_widget)
        
        # Zero-Based Budget Summary
        summary_group = QGroupBox("Zero-Based Budget Summary")
        summary_layout = QVBoxLayout(summary_group)
        
        self.total_income_label = QLabel("Total Expected Income: $0.00")
        self.total_allocated_label = QLabel("Total Allocated: $0.00")
        self.unallocated_label = QLabel("Unallocated Funds: $0.00")
        self.savings_allocated_label = QLabel("Allocated to Savings: $0.00")
        
        summary_layout.addWidget(self.total_income_label)
        summary_layout.addWidget(self.total_allocated_label)
        summary_layout.addWidget(self.savings_allocated_label)
        summary_layout.addWidget(self.unallocated_label)
        
        layout.addWidget(summary_group)
        
        # Budget Balance Check
        balance_group = QGroupBox("Budget Balance")
        self.balance_layout = QVBoxLayout(balance_group)
        layout.addWidget(balance_group)
        
        return overview_widget
        
    def on_budget_category_changed(self):
        """Handle budget main category selection change."""
        main_category = self.budget_main_category_combo.currentText()
        self.update_budget_subcategory_combo(main_category)
        
    def update_budget_subcategory_combo(self, main_category: str):
        """Update budget subcategory combo based on main category."""
        current_text = self.budget_subcategory_combo.currentText()
        self.budget_subcategory_combo.clear()
        
        if main_category:
            subcategories = self.category_manager.get_subcategories(main_category)
            self.budget_subcategory_combo.addItems(subcategories)
            
        if current_text:
            self.budget_subcategory_combo.setCurrentText(current_text)
            
    def add_income_source(self):
        """Add an income source to planning."""
        source = self.income_source_combo.currentText().strip()
        amount = self.income_amount_input.value()
        
        if not source:
            QMessageBox.warning(
                self, "Missing Source", "Please enter an income source."
            )
            return
            
        if amount <= 0:
            QMessageBox.warning(
                self, "Invalid Amount", "Please enter a valid amount greater than 0."
            )
            return
            
        # This would be saved as expected income (implementation depends on data structure)
        QMessageBox.information(
            self, "Success", f"Income source '{source}' added: {format_currency(amount)}"
        )
        
        # Clear inputs
        self.income_amount_input.setValue(0)
        self.income_source_combo.setCurrentText("")
        
    def set_budget(self):
        """Set budget for a category:subcategory."""
        main_category = self.budget_main_category_combo.currentText().strip()
        subcategory = self.budget_subcategory_combo.currentText().strip()
        amount = self.budget_amount_input.value()
        
        if not main_category or not subcategory:
            QMessageBox.warning(
                self, "Missing Information", 
                "Please select both main category and subcategory."
            )
            return
            
        if amount <= 0:
            QMessageBox.warning(
                self, "Invalid Amount", 
                "Please enter a valid budget amount greater than 0."
            )
            return
            
        # Format as "MainCategory:Subcategory"
        full_category = f"{main_category}:{subcategory}"
        self.data_manager.set_budget(full_category, amount)
        
        self.budget_amount_input.setValue(0)
        
        self.update_budget_overview()
        self.update_overview()
        self.data_changed.emit()
        
        QMessageBox.information(
            self, "Success", 
            f"Budget set for {full_category}: {format_currency(amount)}"
        )
        
    def set_savings_goal(self):
        """Set a savings goal."""
        goal = self.savings_goal_combo.currentText().strip()
        amount = self.savings_amount_input.value()
        
        if not goal:
            QMessageBox.warning(
                self, "Missing Goal", "Please enter a savings goal."
            )
            return
            
        if amount <= 0:
            QMessageBox.warning(
                self, "Invalid Amount", 
                "Please enter a valid savings amount greater than 0."
            )
            return
            
        self.data_manager.set_savings_goal(goal, amount)
        
        self.savings_amount_input.setValue(0)
        self.savings_goal_combo.setCurrentText("")
        
        self.update_savings_table()
        self.update_overview()
        self.data_changed.emit()
        
        QMessageBox.information(
            self, "Success", 
            f"Savings goal set for {goal}: {format_currency(amount)}"
        )
        
    def update_budget_overview(self):
        """Update the budget overview display."""
        # Clear existing widgets
        for i in reversed(range(self.budget_overview_layout.count())):
            child = self.budget_overview_layout.takeAt(i).widget()
            if child:
                child.setParent(None)
                
        budgets = self.data_manager.get_budgets()
        if not budgets:
            no_budget_label = QLabel("No budgets set. Set some budgets to track spending!")
            self.budget_overview_layout.addWidget(no_budget_label)
            return
            
        # Get current month expenses
        expenses = self.data_manager.get_expenses()
        current_expenses = filter_expenses_by_month(expenses)
        
        for category, budget_amount in budgets.items():
            category_spent = sum(
                exp['amount'] for exp in current_expenses
                if exp['category'] == category
            )
            remaining = budget_amount - category_spent
            percentage = calculate_budget_percentage(category_spent, budget_amount)
            
            # Create category widget
            category_widget = QWidget()
            category_layout = QVBoxLayout(category_widget)
            
            # Category name and amounts
            info_label = QLabel(
                f"{category}: {format_currency(category_spent)} / {format_currency(budget_amount)}"
            )
            category_layout.addWidget(info_label)
            
            # Progress bar
            progress_bar = QProgressBar()
            progress_bar.setValue(int(percentage))
            
            # Color coding
            if percentage >= 100:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #e74c3c; }"
                )
            elif percentage >= 80:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #f39c12; }"
                )
            else:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #27ae60; }"
                )
                
            category_layout.addWidget(progress_bar)
            
            # Remaining amount
            remaining_label = QLabel(f"Remaining: {format_currency(remaining)}")
            if remaining < 0:
                remaining_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
            category_layout.addWidget(remaining_label)
            
            self.budget_overview_layout.addWidget(category_widget)
            
    def update_savings_table(self):
        """Update the savings goals table."""
        goals = self.data_manager.get_savings_goals()
        self.savings_table.setRowCount(len(goals))
        
        for row, (goal, target) in enumerate(goals.items()):
            self.savings_table.setItem(row, 0, QTableWidgetItem(goal))
            self.savings_table.setItem(row, 1, QTableWidgetItem(format_currency(target)))
            
            # Calculate actual savings (this would need to be implemented)
            progress_bar = QProgressBar()
            progress_bar.setValue(0)  # Placeholder
            self.savings_table.setCellWidget(row, 2, progress_bar)
            
            # Delete button
            delete_button = QPushButton("Delete")
            self.savings_table.setCellWidget(row, 3, delete_button)
            
    def update_overview(self):
        """Update the zero-based budget overview."""
        # Get totals
        budgets = self.data_manager.get_budgets()
        savings_goals = self.data_manager.get_savings_goals()
        monthly_totals = self.data_manager.get_monthly_totals()
        
        total_income = monthly_totals['income']
        total_budgeted = sum(budgets.values())
        total_savings_goals = sum(savings_goals.values())
        total_allocated = total_budgeted + total_savings_goals
        unallocated = total_income - total_allocated
        
        # Update labels
        self.total_income_label.setText(
            f"Total Expected Income: {format_currency(total_income)}"
        )
        self.total_allocated_label.setText(
            f"Total Allocated: {format_currency(total_allocated)}"
        )
        self.savings_allocated_label.setText(
            f"Allocated to Savings: {format_currency(total_savings_goals)}"
        )
        self.unallocated_label.setText(
            f"Unallocated Funds: {format_currency(unallocated)}"
        )
        
        # Color code unallocated amount
        if unallocated < 0:
            self.unallocated_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
        elif unallocated > 0:
            self.unallocated_label.setStyleSheet("color: #f39c12; font-weight: bold;")
        else:
            self.unallocated_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            
    def refresh_data(self):
        """Refresh all tab data displays."""
        self.update_budget_overview()
        self.update_savings_table()
        self.update_overview()
        if hasattr(self, 'budget_main_category_combo'):
            self.on_budget_category_changed()
