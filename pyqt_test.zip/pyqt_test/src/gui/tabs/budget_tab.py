"""
Budget Tab Module
Contains the budget management tab widget.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QGroupBox, QGridLayout, QLabel,
    QComboBox, QDoubleSpinBox, QPushButton, QProgressBar, QMessageBox
)
from PyQt6.QtCore import pyqtSignal

from ...data.data_manager import DataManager
from ...utils.helpers import (
    get_default_categories, filter_expenses_by_month,
    calculate_budget_percentage
)


class BudgetTab(QWidget):
    """Widget for managing budgets and viewing budget progress."""
    
    data_changed = pyqtSignal()
    
    def __init__(self, data_manager: DataManager):
        super().__init__()
        self.data_manager = data_manager
        self.init_ui()
        
    def init_ui(self):
        """Initialize the budget tab user interface."""
        layout = QVBoxLayout(self)
        
        # Budget setup section
        budget_group = QGroupBox("Set Category Budgets")
        budget_layout = QGridLayout(budget_group)
        
        budget_layout.addWidget(QLabel("Category:"), 0, 0)
        self.budget_category_combo = QComboBox()
        self.budget_category_combo.setEditable(True)
        self.update_budget_category_combo()
        budget_layout.addWidget(self.budget_category_combo, 0, 1)
        
        budget_layout.addWidget(QLabel("Monthly Budget:"), 0, 2)
        self.budget_amount_input = QDoubleSpinBox()
        self.budget_amount_input.setMaximum(99999.99)
        self.budget_amount_input.setPrefix("$")
        budget_layout.addWidget(self.budget_amount_input, 0, 3)
        
        set_budget_button = QPushButton("Set Budget")
        set_budget_button.clicked.connect(self.set_budget)
        budget_layout.addWidget(set_budget_button, 1, 0, 1, 4)
        
        layout.addWidget(budget_group)
        
        # Budget overview
        overview_group = QGroupBox("Budget Overview")
        self.budget_overview_layout = QVBoxLayout(overview_group)
        layout.addWidget(overview_group)
        
        self.update_budget_overview()
        
    def set_budget(self):
        """Set budget for a category."""
        category = self.budget_category_combo.currentText().strip()
        amount = self.budget_amount_input.value()
        
        if not category:
            QMessageBox.warning(
                self, "Missing Category", "Please enter a category."
            )
            return
            
        if amount <= 0:
            QMessageBox.warning(
                self, "Invalid Amount",
                "Please enter a valid budget amount greater than 0."
            )
            return
            
        self.data_manager.set_budget(category, amount)
        
        self.budget_amount_input.setValue(0)
        self.budget_category_combo.setCurrentText("")
        
        self.update_budget_overview()
        self.data_changed.emit()
        
        QMessageBox.information(
            self, "Success", f"Budget set for {category}: ${amount:.2f}"
        )
        
    def update_budget_overview(self):
        """Update budget overview display."""
        # Clear existing widgets
        for i in reversed(range(self.budget_overview_layout.count())):
            child = self.budget_overview_layout.takeAt(i).widget()
            if child:
                child.setParent(None)
                
        budgets = self.data_manager.get_budgets()
        if not budgets:
            no_budget_label = QLabel(
                "No budgets set. Add some budgets to track your spending!"
            )
            self.budget_overview_layout.addWidget(no_budget_label)
            return
            
        # Get current month expenses
        expenses = self.data_manager.get_expenses()
        current_expenses = filter_expenses_by_month(expenses)
        
        for category, budget_amount in budgets.items():
            category_spent = sum(
                exp['amount'] for exp in current_expenses
                if exp['category'] == category
            )
            remaining = budget_amount - category_spent
            percentage = calculate_budget_percentage(
                category_spent, budget_amount
            )
            
            # Create category widget
            category_widget = QWidget()
            category_layout = QVBoxLayout(category_widget)
            
            # Category name and amounts
            info_label = QLabel(
                f"{category}: ${category_spent:.2f} / ${budget_amount:.2f}"
            )
            category_layout.addWidget(info_label)
            
            # Progress bar
            progress_bar = QProgressBar()
            progress_bar.setValue(int(percentage))
            
            # Color coding
            if percentage >= 100:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #e74c3c; }"
                )
            elif percentage >= 80:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #f39c12; }"
                )
            else:
                progress_bar.setStyleSheet(
                    "QProgressBar::chunk { background-color: #27ae60; }"
                )
                
            category_layout.addWidget(progress_bar)
            
            # Remaining amount
            remaining_label = QLabel(f"Remaining: ${remaining:.2f}")
            if remaining < 0:
                remaining_label.setStyleSheet(
                    "color: #e74c3c; font-weight: bold;"
                )
            category_layout.addWidget(remaining_label)
            
            self.budget_overview_layout.addWidget(category_widget)
            
    def update_budget_category_combo(self):
        """Update budget category combo box."""
        current_text = self.budget_category_combo.currentText()
        self.budget_category_combo.clear()
        
        existing_categories = self.data_manager.get_categories()
        default_categories = set(get_default_categories())
        
        all_categories = sorted(existing_categories.union(default_categories))
        self.budget_category_combo.addItems(all_categories)
        self.budget_category_combo.setCurrentText(current_text)
        
    def refresh_data(self):
        """Refresh the tab data display."""
        self.update_budget_overview()
        self.update_budget_category_combo()
