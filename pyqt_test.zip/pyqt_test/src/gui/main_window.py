"""
Main Window Module
Contains the main application window and tab management.
"""

import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QTabWidget
)

from .tabs.spending_tab import SpendingTab
from .tabs.zero_based_budget_tab import ZeroBasedBudgetTab
from .tabs.reports_tab import ReportsTab
from ..data.data_manager import DataManager


class BudgetTracker(QMainWindow):
    """Main application window for the Budget Tracker."""
    
    def __init__(self):
        super().__init__()
        self.data_manager = DataManager()
        self.data_manager.load_data()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle("Budget Spending Tracker")
        self.setGeometry(100, 100, 1000, 700)
        
        # Set up main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        
        # Create tab widget
        tab_widget = QTabWidget()
        main_layout = QVBoxLayout(main_widget)
        main_layout.addWidget(tab_widget)
        
        # Create tabs
        self.spending_tab = SpendingTab(self.data_manager)
        self.budget_tab = ZeroBasedBudgetTab(self.data_manager)
        self.reports_tab = ReportsTab(self.data_manager)
        
        tab_widget.addTab(self.spending_tab, "Transactions")
        tab_widget.addTab(self.budget_tab, "Zero-Based Budget")
        tab_widget.addTab(self.reports_tab, "Reports")
        
        # Connect signals for data updates
        self.spending_tab.data_changed.connect(self.on_data_changed)
        self.budget_tab.data_changed.connect(self.on_data_changed)
        
        # Apply styling
        self.apply_styling()
        
    def on_data_changed(self):
        """Handle data changes by updating all tabs."""
        self.spending_tab.refresh_data()
        self.budget_tab.refresh_data()
        self.reports_tab.refresh_data()
        
    def apply_styling(self):
        """Apply custom styling to the application."""
        self.setStyleSheet("""
            /* Main Window Styling */
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #f8f9fa, stop:1 #e9ecef);
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            
            /* Tab Widget Styling */
            QTabWidget::pane {
                border: 2px solid #6c757d;
                border-radius: 8px;
                background-color: white;
                margin-top: 5px;
            }
            
            QTabWidget::tab-bar {
                alignment: center;
            }
            
            QTabBar::tab {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #007bff, stop:1 #0056b3);
                color: white;
                border: none;
                padding: 12px 24px;
                margin-right: 2px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                font-weight: 600;
                font-size: 11pt;
                min-width: 120px;
            }
            
            QTabBar::tab:selected {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #28a745, stop:1 #1e7e34);
                border-bottom: 3px solid #ffc107;
            }
            
            QTabBar::tab:hover:!selected {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #17a2b8, stop:1 #138496);
            }
            
            /* Group Box Styling */
            QGroupBox {
                font-weight: 600;
                font-size: 12pt;
                border: 2px solid #6c757d;
                border-radius: 10px;
                margin: 15px 5px;
                padding-top: 20px;
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #ffffff, stop:1 #f8f9fa);
            }
            
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 5px 10px;
                background-color: #007bff;
                color: white;
                border-radius: 5px;
                font-weight: bold;
            }
            
            /* Button Styling */
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #28a745, stop:1 #1e7e34);
                color: white;
                border: none;
                padding: 12px 20px;
                border-radius: 8px;
                font-weight: 600;
                font-size: 10pt;
                min-height: 20px;
            }
            
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #20c997, stop:1 #17a2b8);
                border: 2px solid #ffc107;
            }
            
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #155724, stop:1 #0c5460);
                border: 2px solid #fd7e14;
            }
            
            /* Special button colors */
            QPushButton[objectName="csv_upload_button"] {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #fd7e14, stop:1 #e55300);
            }
            
            QPushButton[objectName="csv_upload_button"]:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #ff8800, stop:1 #cc6600);
            }
            
            QPushButton[objectName="delete_button"] {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #dc3545, stop:1 #c82333);
                padding: 8px 16px;
                font-size: 9pt;
            }
            
            QPushButton[objectName="delete_button"]:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #e74c3c, stop:1 #c0392b);
            }
            
            /* Input Field Styling */
            QLineEdit, QDoubleSpinBox, QComboBox, QDateEdit {
                padding: 10px;
                border: 2px solid #dee2e6;
                border-radius: 6px;
                background-color: white;
                font-size: 10pt;
                selection-background-color: #007bff;
            }
            
            QLineEdit:focus, QDoubleSpinBox:focus, QComboBox:focus, QDateEdit:focus {
                border-color: #007bff;
                background-color: #f8f9ff;
            }
            
            QComboBox::drop-down {
                border: none;
                border-top-right-radius: 6px;
                border-bottom-right-radius: 6px;
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #007bff, stop:1 #0056b3);
                width: 30px;
            }
            
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid white;
                margin: 10px;
            }
            
            /* Table Styling */
            QTableWidget {
                gridline-color: #dee2e6;
                background-color: white;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                font-size: 10pt;
            }
            
            QHeaderView::section {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #343a40, stop:1 #495057);
                color: white;
                padding: 12px;
                border: none;
                font-weight: 600;
                font-size: 10pt;
            }
            
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #dee2e6;
            }
            
            QTableWidget::item:selected {
                background-color: #e3f2fd;
                color: #1976d2;
            }
            
            QTableWidget::item:hover {
                background-color: #f5f5f5;
            }
            
            /* Radio Button Styling */
            QRadioButton {
                font-weight: 500;
                font-size: 10pt;
                spacing: 8px;
                color: #495057;
            }
            
            QRadioButton::indicator {
                width: 16px;
                height: 16px;
                border-radius: 8px;
                border: 2px solid #6c757d;
                background-color: white;
            }
            
            QRadioButton::indicator:checked {
                background-color: #007bff;
                border-color: #0056b3;
            }
            
            /* Progress Bar Styling */
            QProgressBar {
                border: 2px solid #dee2e6;
                border-radius: 8px;
                text-align: center;
                font-weight: 600;
                font-size: 10pt;
                background-color: #f8f9fa;
                height: 25px;
            }
            
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #28a745, stop:0.5 #20c997, stop:1 #17a2b8);
                border-radius: 6px;
                margin: 2px;
            }
            
            /* Label Styling */
            QLabel {
                color: #495057;
                font-size: 10pt;
                font-weight: 500;
            }
            
            /* Scroll Bar Styling */
            QScrollBar:vertical {
                border: none;
                background-color: #f8f9fa;
                width: 12px;
                border-radius: 6px;
            }
            
            QScrollBar::handle:vertical {
                background-color: #6c757d;
                border-radius: 6px;
                min-height: 20px;
            }
            
            QScrollBar::handle:vertical:hover {
                background-color: #495057;
            }
        """)


def main():
    """Main application entry point."""
    app = QApplication(sys.argv)
    
    # Set application properties
    app.setApplicationName("Budget Spending Tracker")
    app.setOrganizationName("Budget Tracker")
    
    window = BudgetTracker()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
